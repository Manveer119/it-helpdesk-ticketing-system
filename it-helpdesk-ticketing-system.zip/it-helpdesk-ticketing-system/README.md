# IT Help Desk Ticketing System & Knowledge Base

A command-line IT help desk ticketing tool with a SQLite backend,
built-in reporting on ticket volume and resolution times, and a
knowledge base of runbooks written from resolved tickets — modeling
the core workflow of tools like ServiceNow on a smaller scale.

## Why I built this

During my internship at Flyt Moving, I worked daily in ServiceNow
logging and resolving tickets, and in Active Directory managing user
accounts. This project rebuilds that workflow from the ground up —
database design, ticket lifecycle logic, reporting, and technical
documentation — to show I understand not just how to *use* a
ticketing system, but how one works and how to report on it.

## What it does

**1. Ticket management (`ticketing_system.py`)**
A CLI tool to create tickets, update their status as they're worked,
close them with resolution notes, and search/filter the queue —
covering the same lifecycle (Open → In Progress → Resolved → Closed)
as real ITSM tools.

**2. Reporting & metrics (`analysis.py`)**
Generates three charts and a text summary from the ticket data:
- Ticket volume by category (where is support time going?)
- Average resolution time by priority (a basic SLA view)
- Ticket volume by month (trend over time)

| Volume by Category | Resolution Time by Priority |
|---|---|
| ![Volume by category](reports/volume_by_category.png) | ![Resolution time](reports/resolution_time_by_priority.png) |

**3. Knowledge base (`knowledge_base/`)**
Five runbooks written from the recurring issues in the sample ticket
data — account lockouts, printer connectivity, VPN failures, MFA
issues, and a new-hire provisioning checklist. Each follows a
consistent Symptom → Cause → Resolution → Prevention format so a
technician can act on it quickly.

## Tech stack
- **Python 3** — CLI application logic
- **SQLite** — relational database (users, categories, tickets)
- **pandas / matplotlib** — reporting and chart generation
- **Markdown** — knowledge base documentation

## Project structure
```
it-helpdesk-ticketing-system/
├── schema.sql              # Database schema (users, categories, tickets)
├── seed_data.py            # Builds the DB and loads 60 realistic sample tickets
├── ticketing_system.py     # Interactive CLI: create/update/close/search tickets
├── analysis.py             # Generates reports and charts from ticket data
├── knowledge_base/         # 5 runbooks + index
├── reports/                # Generated charts and summary.txt (from analysis.py)
├── data/                   # SQLite database (created by seed_data.py, not tracked in git)
└── requirements.txt
```

## How to run it

```bash
# 1. Clone the repo and move into it
git clone https://github.com/<your-username>/it-helpdesk-ticketing-system.git
cd it-helpdesk-ticketing-system

# 2. Install dependencies
pip install -r requirements.txt

# 3. Build and seed the database (60 sample tickets across 8 categories)
python seed_data.py

# 4. Run the ticketing tool
python ticketing_system.py

# 5. Generate the reporting charts
python analysis.py
```

## Sample data
The database is seeded with 60 realistic tickets spanning April–July
2026 across 12 fictional users and 8 categories: Hardware, Network,
Printer, Account/Active Directory, Software Install, Email/M365,
Asset Request, and VPN/Remote Access — chosen to mirror the ticket
mix typical of a general IT support desk.

## Design notes
- **Priority-based resolution SLAs**: sample data models realistic
  patterns where Critical tickets (e.g., account lockouts, VPN down)
  resolve in hours while Low priority tickets (e.g., toner swaps) can
  sit longer — the kind of triage judgment an IT support role
  requires.
- **Resolution notes feed the knowledge base**: closing a ticket
  captures what fixed it, mirroring how real KB articles should
  originate from actual resolved cases rather than being written in
  the abstract.

## Possible extensions
- Add a lightweight Flask front end instead of CLI-only
- Email notifications on ticket status changes
- Asset inventory table linked to tickets (device history per asset)
